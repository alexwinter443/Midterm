<html>
<head><base>
<title>MidTerm</title>
</head>

<body>
	<div>
		<!--  this takes us to the route '/doLogin' within web.php -->
		<form action="assessment" method="post">
		    <!-- hidden field that is required-->
			{{ csrf_field() }}
			
			<div class = "demo-table">
				<div class = "form-head">Midterm Form</div>
				<!-- Username Form -->
				<div class="form-column">
					<div>
						<label for="firstName">firstName</label><span id="firstName" class="error-info"></span>
					</div>	
					<div>
						<input name="firstName" id="firstName" type="text" class="demo-input-box">
						<?php echo $errors->first('firstName')?>
					</div>		
				</div>
				<!-- End Username -->
				<!-- Password Form -->
				<div class="form-column">
					<div>
						<label for="lastName">lastName</label><span id="lastName" class="error-info"></span>
					</div>	
					<div>
						<input name="lastName" id="lastName" type="text" class="demo-input-box">
						<?php echo $errors->first('lastName')?>
					</div>		
				</div>
				<div class="form-column">
					<div>
						<label for="school">school</label><span id="school" class="error-info"></span>
					</div>	
					<div>
						<input name="school" id="school" type="text" class="demo-input-box">
						<?php echo $errors->first('school')?>
					</div>		
				</div>
				<div class="form-column">
					<div>
						<label for="password">password</label><span id="password" class="error-info"></span>
					</div>	
					<div>
						<input name="password" id="password" type="text" class="demo-input-box">
						<?php echo $errors->first('password')?>
					</div>		
				</div>
				<div>
					<input type="submit" value="Submit Form" class="btnLogin" >
				</div>
				<br>
				<!-- Result if CST-256 was found -->
				<div class="form-column">
					<div>
						<label for="result">Result: </label><span id="result" class="error-info"></span>
					</div>	
					<div>
					<!-- Checks if variable $result is set/declared -->
					 @if(isset($result))
					    <!-- if match was found -->
					 	@if($result == true)
					 		<h4>True. CST-256 was found</h4>
					    <!-- if match was NOT found -->
					    @else
					    	<h4>False. CST-256 was NOT found</h4>
					 	@endif
   					 @endif
					</div>		
				</div>
			</div>
		
		</form>
	</div>



</body>

</html>