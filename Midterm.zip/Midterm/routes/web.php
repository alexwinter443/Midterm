<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// welcom page
Route::get('/', function () {
    return view('welcome');
});


// assessment get route
Route::get('/assessment', function(){
    return view('assessment');
});
    
// assesment post route
Route::post('/assessment', 'FormController@index');








Route::get('/login', function(){
    return view('loginView');
    //echo('This is a test');
    
});

// when the data is posted from the login page
// with the action set to 'doLogin' it will com here
// Then the route the request to the function called index
// in the login controller
Route::post('/doLogin', 'LoginController@index');


// Route::get('/login2', function(){
//    return view('loginView2'); 
// });












