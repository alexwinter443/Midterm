<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Symfony\Contracts\Service\Attribute\Required;
use App\Models\FormModel;
use App\services\Business\FormBusinessService;


class FormController extends Controller
{
    // We obtained an instance of the current http request from the post   
    public function index (Request $request)
    {       
        // Here we assign our variables to the values taken from our form.
        $firstName = $request->input('firstName');
        $lastName = $request->input('lastName');
        $school = $request->input('school');
        $password = $request->input('password');
        // Now our FormModel is constructed with actual values
        $userModel = new FormModel($firstName, $lastName, $school, $password);
        
        // create service
        $formService = new FormBusinessService();
        
        // use service method , return true or false
        $result = $formService->signIn($userModel);
        
        // return view with data
        return view('assessment')->with('result', $result);
       
            
             
    }
    
    
    
}
