<?php

namespace App\services\Business;

use App\Models\FormModel;

class FormBusinessService{
    
    // this function will determine is any of the input fields has enter "CST256"
    public function signIn(FormModel $formModel){
        // check if first name is equal to "CST-256"
        if($formModel->getFirstName() == "CST-256"){
            return true;
        }
        // check if last name is equal to "CST-256"
        else if($formModel->getLastName() == "CST-256"){
            return true;
        }
        // check if school is equal to "CST-256"
        else if($formModel->getSchool() == "CST-256"){
            return true;
        }
        // check if password is equal to "CST-256"
        else if($formModel->getPassword() == "CST-256"){
            return true;
        }
        // else no matches
        else{
            return false;
        }
    }
}